/****************************************************************************
** Meta object code from reading C++ file 'student_management.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../student_management.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'student_management.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_StudentManagement_t {
    QByteArrayData data[36];
    char stringdata0[495];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_StudentManagement_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_StudentManagement_t qt_meta_stringdata_StudentManagement = {
    {
QT_MOC_LITERAL(0, 0, 17), // "StudentManagement"
QT_MOC_LITERAL(1, 18, 11), // "handleLogin"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 10), // "GoToSignUp"
QT_MOC_LITERAL(4, 42, 9), // "GoToLogin"
QT_MOC_LITERAL(5, 52, 6), // "SignUp"
QT_MOC_LITERAL(6, 59, 15), // "ShowChildSignUp"
QT_MOC_LITERAL(7, 75, 12), // "handleLogout"
QT_MOC_LITERAL(8, 88, 12), // "goToMainMenu"
QT_MOC_LITERAL(9, 101, 12), // "goToSettings"
QT_MOC_LITERAL(10, 114, 8), // "goToMail"
QT_MOC_LITERAL(11, 123, 10), // "AddSubject"
QT_MOC_LITERAL(12, 134, 18), // "RefreshEnrollments"
QT_MOC_LITERAL(13, 153, 16), // "CreateAssignment"
QT_MOC_LITERAL(14, 170, 22), // "FillInComboBoxSubjects"
QT_MOC_LITERAL(15, 193, 15), // "ViewAssignments"
QT_MOC_LITERAL(16, 209, 20), // "ShowCreateAssignment"
QT_MOC_LITERAL(17, 230, 10), // "UploadFile"
QT_MOC_LITERAL(18, 241, 14), // "OpenAssignment"
QT_MOC_LITERAL(19, 256, 16), // "QTreeWidgetItem*"
QT_MOC_LITERAL(20, 273, 4), // "item"
QT_MOC_LITERAL(21, 278, 6), // "column"
QT_MOC_LITERAL(22, 285, 12), // "DownloadFile"
QT_MOC_LITERAL(23, 298, 19), // "CloseAssignmentInfo"
QT_MOC_LITERAL(24, 318, 20), // "UploadSubmissionFile"
QT_MOC_LITERAL(25, 339, 16), // "SubmitAssignment"
QT_MOC_LITERAL(26, 356, 15), // "ViewSubmissions"
QT_MOC_LITERAL(27, 372, 19), // "CloseSubmissionInfo"
QT_MOC_LITERAL(28, 392, 14), // "OpenSubmission"
QT_MOC_LITERAL(29, 407, 15), // "GradeSubmission"
QT_MOC_LITERAL(30, 423, 13), // "UpdateAccount"
QT_MOC_LITERAL(31, 437, 11), // "SendNewMail"
QT_MOC_LITERAL(32, 449, 12), // "RefreshInbox"
QT_MOC_LITERAL(33, 462, 11), // "RefreshSent"
QT_MOC_LITERAL(34, 474, 14), // "MailTabChanged"
QT_MOC_LITERAL(35, 489, 5) // "index"

    },
    "StudentManagement\0handleLogin\0\0"
    "GoToSignUp\0GoToLogin\0SignUp\0ShowChildSignUp\0"
    "handleLogout\0goToMainMenu\0goToSettings\0"
    "goToMail\0AddSubject\0RefreshEnrollments\0"
    "CreateAssignment\0FillInComboBoxSubjects\0"
    "ViewAssignments\0ShowCreateAssignment\0"
    "UploadFile\0OpenAssignment\0QTreeWidgetItem*\0"
    "item\0column\0DownloadFile\0CloseAssignmentInfo\0"
    "UploadSubmissionFile\0SubmitAssignment\0"
    "ViewSubmissions\0CloseSubmissionInfo\0"
    "OpenSubmission\0GradeSubmission\0"
    "UpdateAccount\0SendNewMail\0RefreshInbox\0"
    "RefreshSent\0MailTabChanged\0index"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_StudentManagement[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      30,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  164,    2, 0x08 /* Private */,
       3,    0,  165,    2, 0x08 /* Private */,
       4,    0,  166,    2, 0x08 /* Private */,
       5,    0,  167,    2, 0x08 /* Private */,
       6,    0,  168,    2, 0x08 /* Private */,
       7,    0,  169,    2, 0x08 /* Private */,
       8,    0,  170,    2, 0x08 /* Private */,
       9,    0,  171,    2, 0x08 /* Private */,
      10,    0,  172,    2, 0x08 /* Private */,
      11,    0,  173,    2, 0x08 /* Private */,
      12,    0,  174,    2, 0x08 /* Private */,
      13,    0,  175,    2, 0x08 /* Private */,
      14,    0,  176,    2, 0x08 /* Private */,
      15,    0,  177,    2, 0x08 /* Private */,
      16,    0,  178,    2, 0x08 /* Private */,
      17,    0,  179,    2, 0x08 /* Private */,
      18,    2,  180,    2, 0x08 /* Private */,
      22,    0,  185,    2, 0x08 /* Private */,
      23,    0,  186,    2, 0x08 /* Private */,
      24,    0,  187,    2, 0x08 /* Private */,
      25,    0,  188,    2, 0x08 /* Private */,
      26,    0,  189,    2, 0x08 /* Private */,
      27,    0,  190,    2, 0x08 /* Private */,
      28,    2,  191,    2, 0x08 /* Private */,
      29,    0,  196,    2, 0x08 /* Private */,
      30,    0,  197,    2, 0x08 /* Private */,
      31,    0,  198,    2, 0x08 /* Private */,
      32,    0,  199,    2, 0x08 /* Private */,
      33,    0,  200,    2, 0x08 /* Private */,
      34,    1,  201,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 19, QMetaType::Int,   20,   21,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 19, QMetaType::Int,   20,   21,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   35,

       0        // eod
};

void StudentManagement::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        StudentManagement *_t = static_cast<StudentManagement *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->handleLogin(); break;
        case 1: _t->GoToSignUp(); break;
        case 2: _t->GoToLogin(); break;
        case 3: _t->SignUp(); break;
        case 4: _t->ShowChildSignUp(); break;
        case 5: _t->handleLogout(); break;
        case 6: _t->goToMainMenu(); break;
        case 7: _t->goToSettings(); break;
        case 8: _t->goToMail(); break;
        case 9: _t->AddSubject(); break;
        case 10: _t->RefreshEnrollments(); break;
        case 11: _t->CreateAssignment(); break;
        case 12: _t->FillInComboBoxSubjects(); break;
        case 13: _t->ViewAssignments(); break;
        case 14: _t->ShowCreateAssignment(); break;
        case 15: _t->UploadFile(); break;
        case 16: _t->OpenAssignment((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 17: _t->DownloadFile(); break;
        case 18: _t->CloseAssignmentInfo(); break;
        case 19: _t->UploadSubmissionFile(); break;
        case 20: _t->SubmitAssignment(); break;
        case 21: _t->ViewSubmissions(); break;
        case 22: _t->CloseSubmissionInfo(); break;
        case 23: _t->OpenSubmission((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 24: _t->GradeSubmission(); break;
        case 25: _t->UpdateAccount(); break;
        case 26: _t->SendNewMail(); break;
        case 27: _t->RefreshInbox(); break;
        case 28: _t->RefreshSent(); break;
        case 29: _t->MailTabChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject StudentManagement::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_StudentManagement.data,
    qt_meta_data_StudentManagement,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *StudentManagement::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *StudentManagement::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_StudentManagement.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int StudentManagement::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 30)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 30;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 30)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 30;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE

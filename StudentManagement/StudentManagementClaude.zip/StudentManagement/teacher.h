#pragma once
#include "user.h"
#include <vector>
class Subject; //cannot just include it because we did it in subjects.h so it will go in circles and bug

class Teacher : public User {
public:
	Teacher(const std::string& _email, const std::string& _password, const std::string& _name,
		const std::string& _surname, const Date& _dob);

	const std::vector<std::shared_ptr<Subject>>& GetSubjects() const;
	void AddSubject(std::shared_ptr<Subject> _subject);

	std::string ToString() const;

	std::string GetRole() const override;

private:
	std::vector<std::shared_ptr<Subject>> m_subjects;
};